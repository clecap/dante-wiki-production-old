<?php 
wfLoadExtension( 'WikiMarkdown' );
wfLoadExtension( 'MobileFrontend' );
wfLoadExtension( 'HideSection' );
wfLoadExtension( 'RandomSelection' );
wfLoadExtension( 'LabeledSectionTransclusion' );
wfLoadExtension( 'RevisionSlider' );
wfLoadExtension( 'NativeSvgHandler' );
wfLoadExtension( 'DrawioEditor' );
wfLoadExtension( 'DynamicPageList3' );
