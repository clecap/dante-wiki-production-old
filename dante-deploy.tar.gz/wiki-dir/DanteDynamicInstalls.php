<?php 
wfLoadExtension( 'WikiMarkdown' );
wfLoadExtension( 'MobileFrontend' );
wfLoadExtension( 'RandomSelection' );
wfLoadExtension( 'LabeledSectionTransclusion' );
wfLoadExtension( 'RevisionSlider' );
wfLoadExtension( 'NativeSvgHandler' );
wfLoadExtension( 'DrawioEditor' );
wfLoadExtension( 'DynamicPageList3' );
