ALTER TABLE /*_*/uploadstash
  MODIFY us_timestamp BINARY(14) NOT NULL;
