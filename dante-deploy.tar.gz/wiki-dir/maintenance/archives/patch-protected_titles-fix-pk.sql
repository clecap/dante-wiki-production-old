ALTER TABLE /*_*/protected_titles DROP KEY /*i*/pt_namespace_title, ADD PRIMARY KEY (pt_namespace,pt_title);
