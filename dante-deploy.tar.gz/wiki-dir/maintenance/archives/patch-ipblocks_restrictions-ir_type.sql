ALTER TABLE /*_*/ipblocks_restrictions CHANGE COLUMN ir_type ir_type TINYINT(4) NOT NULL;
