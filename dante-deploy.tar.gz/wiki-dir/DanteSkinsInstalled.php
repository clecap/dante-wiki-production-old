<?php 
wfLoadSkin( 'Modern' );
wfLoadSkin( 'Refreshed' );
